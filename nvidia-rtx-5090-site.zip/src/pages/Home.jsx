export default function Home() {
  return (
    <div className="text-center">
      <h1>Nvidia RTX 5090</h1>
      <p>Experience the future of gaming with the most powerful GPU ever built.</p>
      <img src="https://cdn.mos.cms.futurecdn.net/XDQ8rKuUZvDzvZ4R4K2KPB.jpg" alt="RTX 5090" className="img-fluid" />
    </div>
  );
}