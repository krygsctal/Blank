export default function Checkout() {
  return (
    <div>
      <h2>Checkout</h2>
      <p>Please fill in your details to purchase the Nvidia RTX 5090.</p>
      <form>
        <div className="mb-3">
          <label className="form-label">Full Name</label>
          <input type="text" className="form-control" />
        </div>
        <div className="mb-3">
          <label className="form-label">Email</label>
          <input type="email" className="form-control" />
        </div>
        <button type="submit" className="btn btn-primary">Submit Order</button>
      </form>
    </div>
  );
}