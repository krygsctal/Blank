export default function About() {
  return (
    <div>
      <h2>About RTX 5090</h2>
      <p>The Nvidia RTX 5090 is the next-generation GPU built on the Ada Lovelace architecture, featuring up to 50% performance gains over the RTX 4090.</p>
    </div>
  );
}